// STG Command Centre sync
// Gathers YouTube Shorts stats, site up/down status and deploy status,
// then writes JSON files into /data for the dashboard to read.
// Runs in GitHub Actions (see .github/workflows/command-centre-sync.yml).

import { readFile, writeFile, mkdir } from "node:fs/promises";

const CONFIG_PATH = process.env.CC_CONFIG || "command-centre.config.json";
const DATA_DIR = process.env.CC_DATA_DIR || "data";
const YT_KEY = process.env.YOUTUBE_API_KEY || "";
const GH_TOKEN = process.env.GITHUB_TOKEN || "";
const SELF_WORKFLOW = "Command Centre sync";
const DAY = 86400000;
const now = new Date();
const problems = [];

const isPlaceholder = (v) => !v || /REPLACE|OWNER\/REPO|^UC[x]+$/i.test(String(v));

async function readJson(path, fallback) {
  try {
    return JSON.parse(await readFile(path, "utf8"));
  } catch {
    return fallback;
  }
}

async function writeJson(name, obj) {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(`${DATA_DIR}/${name}`, JSON.stringify(obj, null, 2) + "\n");
}

// Error messages never include the query string, so API keys cannot leak into logs or files.
async function getJson(url, headers = {}, timeoutMs = 20000) {
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(timeoutMs) });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} from ${url.split("?")[0]}`);
  return res.json();
}

function isoSeconds(d) {
  const m = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(d || "");
  if (!m) return Infinity;
  return (+m[1] || 0) * 86400 + (+m[2] || 0) * 3600 + (+m[3] || 0) * 60 + (+m[4] || 0);
}

// ---------- YouTube ----------
async function syncYouTube(cfg, prev) {
  try {
    if (!YT_KEY) throw new Error("YOUTUBE_API_KEY secret is not set");
    const hasId = !isPlaceholder(cfg.channelId);
    const hasHandle = !isPlaceholder(cfg.channelHandle);
    if (!hasId && !hasHandle) throw new Error("Set youtube.channelHandle or youtube.channelId in the config file");
    const handle = hasHandle ? (String(cfg.channelHandle).startsWith("@") ? cfg.channelHandle : `@${cfg.channelHandle}`) : "";
    const lookup = hasId ? `id=${encodeURIComponent(cfg.channelId)}` : `forHandle=${encodeURIComponent(handle)}`;
    const base = "https://www.googleapis.com/youtube/v3";

    const chRes = await getJson(`${base}/channels?part=snippet,statistics,contentDetails&${lookup}&key=${YT_KEY}`);
    const ch = chRes.items?.[0];
    if (!ch) throw new Error("Channel not found; check youtube.channelHandle or youtube.channelId");

    const uploads = ch.contentDetails.relatedPlaylists.uploads;
    const list = await getJson(
      `${base}/playlistItems?part=contentDetails&playlistId=${uploads}&maxResults=${Math.min(cfg.scanCount || 30, 50)}&key=${YT_KEY}`
    );
    const ids = (list.items || []).map((i) => i.contentDetails.videoId);
    const vids = ids.length
      ? await getJson(`${base}/videos?part=snippet,statistics,contentDetails&id=${ids.join(",")}&key=${YT_KEY}`)
      : { items: [] };

    const maxSecs = cfg.shortMaxSeconds || 180;
    const shorts = vids.items
      .filter((v) => isoSeconds(v.contentDetails?.duration) <= maxSecs)
      .map((v) => ({
        id: v.id,
        title: v.snippet.title,
        publishedAt: v.snippet.publishedAt,
        views: Number(v.statistics?.viewCount || 0),
        likes: Number(v.statistics?.likeCount || 0),
        comments: Number(v.statistics?.commentCount || 0),
        url: `https://www.youtube.com/shorts/${v.id}`,
      }))
      .sort((a, b) => b.publishedAt.localeCompare(a.publishedAt))
      .slice(0, cfg.recentCount || 10);

    const st = ch.statistics || {};
    return {
      updatedAt: now.toISOString(),
      channel: {
        title: ch.snippet?.title || "",
        subscribers: st.hiddenSubscriberCount ? null : Number(st.subscriberCount || 0),
        totalViews: Number(st.viewCount || 0),
        videoCount: Number(st.videoCount || 0),
      },
      shorts,
    };
  } catch (e) {
    problems.push(`YouTube: ${e.message}`);
    return { ...(prev || {}), error: e.message, errorAt: now.toISOString() };
  }
}

// ---------- Site up/down ----------
async function pingOnce(url) {
  const started = Date.now();
  try {
    const res = await fetch(url, {
      redirect: "follow",
      signal: AbortSignal.timeout(15000),
      headers: { "user-agent": "stg-command-centre/1.0" },
    });
    return { ok: res.ok, status: res.status, error: res.ok ? null : `HTTP ${res.status}`, ms: Date.now() - started };
  } catch (e) {
    const msg = e.name === "TimeoutError" ? "Timed out after 15s" : String(e.message || e);
    return { ok: false, status: null, error: msg, ms: Date.now() - started };
  }
}

async function checkSite(site, prev) {
  let r = await pingOnce(site.url);
  if (!r.ok) {
    await new Promise((res) => setTimeout(res, 5000)); // one retry to avoid false alarms
    r = await pingOnce(site.url);
  }
  const checkedAt = now.toISOString();
  if (!r.ok) problems.push(`${site.name} is down (${r.error})`);
  return {
    id: site.id,
    name: site.name,
    url: site.url,
    ...r,
    checkedAt,
    downSince: r.ok ? null : prev?.downSince || checkedAt,
  };
}

// ---------- Deploys (GitHub Actions + GitHub Deployments, which Vercel reports to) ----------
async function checkRepo(r) {
  const headers = {
    accept: "application/vnd.github+json",
    "x-github-api-version": "2022-11-28",
    "user-agent": "stg-command-centre",
    ...(GH_TOKEN ? { authorization: `Bearer ${GH_TOKEN}` } : {}),
  };
  const api = `https://api.github.com/repos/${r.repo}`;
  const out = { id: r.id, name: r.name, repo: r.repo, url: `https://github.com/${r.repo}`, run: null, deployment: null, notes: [] };

  try {
    const data = await getJson(`${api}/actions/runs?per_page=15`, headers);
    const runs = (data.workflow_runs || []).filter(
      (x) => x.name !== SELF_WORKFLOW && (!r.workflowName || x.name === r.workflowName)
    );
    const run = runs[0];
    if (run) {
      out.run = {
        id: run.id,
        workflow: run.name,
        status: run.status,
        conclusion: run.conclusion,
        url: run.html_url,
        at: run.updated_at,
        sha: (run.head_sha || "").slice(0, 7),
      };
    }
  } catch (e) {
    out.notes.push(`Actions: ${e.message}`);
  }

  try {
    const deps = await getJson(`${api}/deployments?per_page=1`, headers);
    if (deps[0]) {
      const sts = await getJson(`${api}/deployments/${deps[0].id}/statuses?per_page=1`, headers);
      const s = sts[0];
      out.deployment = {
        environment: deps[0].environment,
        state: s?.state || "unknown",
        url: s?.environment_url || s?.target_url || null,
        at: s?.created_at || deps[0].created_at,
      };
    }
  } catch (e) {
    out.notes.push(`Deployments: ${e.message}`);
  }
  return out;
}

// ---------- Suggested tasks ----------
// Task ids are stable while a situation lasts and change when it changes,
// so a ticked task stays ticked until there is something new to do.
function buildTasks(cfg, yt, sites, repos) {
  const tasks = [];
  const ycfg = cfg.youtube || {};

  if (yt && Array.isArray(yt.shorts)) {
    const last = yt.shorts[0];
    const staleAfter = ycfg.staleAfterDays ?? 3;
    if (!last) {
      tasks.push({ id: "post-short:none", tag: "YouTube", title: "Plan and publish a Short", reason: "No Shorts were found on the channel." });
    } else {
      const days = Math.floor((now - new Date(last.publishedAt)) / DAY);
      if (days >= staleAfter) {
        tasks.push({
          id: `post-short:${last.id}`,
          tag: "YouTube",
          title: "Plan and prepare the next YouTube Short",
          reason: `Last Short went out ${days} day${days === 1 ? "" : "s"} ago.`,
          link: last.url,
        });
      }
    }
    const windowDays = ycfg.commentWindowDays ?? 14;
    for (const s of yt.shorts) {
      const age = (now - new Date(s.publishedAt)) / DAY;
      if (s.comments > 0 && age <= windowDays) {
        tasks.push({
          id: `comments:${s.id}:${s.comments}`,
          tag: "YouTube",
          title: `Review and reply to comments on "${s.title}"`,
          reason: `${s.comments} comment${s.comments === 1 ? "" : "s"} on this Short.`,
          link: s.url,
        });
      }
    }
  }

  for (const s of sites) {
    if (!s.ok) {
      tasks.push({
        id: `site-down:${s.id}:${(s.downSince || "").slice(0, 10)}`,
        tag: s.name,
        title: `${s.name} did not respond; check the live site`,
        reason: `${s.error || "Unknown error"} (since ${s.downSince}).`,
        link: s.url,
      });
    }
  }

  for (const r of repos) {
    const bad = r.run && ["failure", "timed_out"].includes(r.run.conclusion);
    if (bad) {
      tasks.push({
        id: `build-failed:${r.id}:${r.run.id}`,
        tag: r.name,
        title: `Fix the failed "${r.run.workflow}" run in ${r.name}`,
        reason: `Latest run (${r.run.sha}) finished with ${r.run.conclusion}.`,
        link: r.run.url,
      });
    }
    if (r.deployment && ["failure", "error"].includes(r.deployment.state)) {
      tasks.push({
        id: `deploy-failed:${r.id}:${r.deployment.at}`,
        tag: r.name,
        title: `Latest ${r.deployment.environment || "deployment"} for ${r.name} failed`,
        reason: `Deployment state: ${r.deployment.state}.`,
        link: r.deployment.url || r.url,
      });
    }
  }
  return tasks;
}

// ---------- Main ----------
async function main() {
  const cfg = await readJson(CONFIG_PATH, null);
  if (!cfg) throw new Error(`Cannot read ${CONFIG_PATH}`);

  const prevYt = await readJson(`${DATA_DIR}/youtube.json`, null);
  const prevStatus = await readJson(`${DATA_DIR}/status.json`, { sites: [] });

  const yt = await syncYouTube(cfg.youtube || {}, prevYt);
  const sites = await Promise.all(
    (cfg.sites || [])
      .filter((s) => !isPlaceholder(s.url))
      .map((s) => checkSite(s, (prevStatus.sites || []).find((p) => p.id === s.id)))
  );
  const repos = await Promise.all((cfg.repos || []).filter((r) => !isPlaceholder(r.repo)).map(checkRepo));
  const tasks = buildTasks(cfg, yt, sites, repos);

  await writeJson("youtube.json", yt);
  await writeJson("status.json", { updatedAt: now.toISOString(), sites, repos });
  await writeJson("auto-tasks.json", { updatedAt: now.toISOString(), tasks });

  console.log(`Sites checked: ${sites.length}, repos checked: ${repos.length}, suggested tasks: ${tasks.length}`);
  if (problems.length) {
    console.error("Problems found:\n- " + problems.join("\n- "));
    // A red workflow run triggers GitHub's own failure email, which doubles as your alert.
    process.exitCode = 1;
  }
}

main().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});
